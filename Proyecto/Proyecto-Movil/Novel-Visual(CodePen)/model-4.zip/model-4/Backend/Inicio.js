
function Inicio(){
    window.location.href = "./index.html";
}
function Config(){
    window.location.href = "./Inicio.html";

}
function Salir(){
    window.location.href = "about:blank";
}